console.log();
let hours = document.getElementById("hours");
let minutes = document.getElementById("min");
let seconds = document.getElementById("sec");

// console.log(currentTime.getDate())

setInterval(() => {


let currentTime= new Date();


hrs=currentTime.getHours();
let ampm = hrs >= 12 ? "PM" : "AM";
    hrs = hrs % 12;
    hrs = hrs ? hrs : 12;
if(hrs<10){
    hours.innerHTML='0'+hrs+':';

}
else{
    hours.innerHTML=hrs+':';

}
minValue=currentTime.getMinutes();
if (minValue<10) {
    minutes.innerHTML='0'+minValue+':';
}
else{
minutes.innerHTML=minValue+':';
}
    
    secValue=currentTime.getSeconds();
    if(secValue<10){
        seconds.innerHTML='0'+secValue+' '+ampm;
    }
    else{
        seconds.innerHTML=secValue+' '+ampm;
    }



}, 1000);